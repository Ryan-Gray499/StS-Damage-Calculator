

# GPL 3.0 license ---------------------------------------------------------


#<This program is the StS Damage Calculator, which calculates damage dealt based on certain conditions in the game Slay the Spire>
    #Copyright (C) <2024>  <Ryan Gray>

    #This program is free software: you can redistribute it and/or modify
    #it under the terms of the GNU General Public License as published by
    #the Free Software Foundation, either version 3 of the License, or
    #(at your option) any later version.

    #This program is distributed in the hope that it will be useful,
    #but WITHOUT ANY WARRANTY; without even the implied warranty of
    #MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    #GNU General Public License for more details.

    #You should have received a copy of the GNU General Public License
    #along with this program.  If not, see <https://www.gnu.org/licenses/>.


# Load packages
library(shiny)
library(shinyjs)
# create theme
theme1 <- bslib::bs_theme(
  bg = "black", 
  fg = "white",
  base_font = "Source Sans Pro"
)
# call functions
source("functions\\FunctionsV3.R")

# call card database
source("data\\card_data.R")


# Ironclad damage Module ---------------------------------------------------------

# Ironclad damgage UI

ironcladDamageUI <- function(id) {
  ns <- NS(id)
  tagList(
    radioButtons(NS(id, "card"), "Choose Card", choices = clad_cards, inline = TRUE),
    selectInput(NS(id, "perfected_strike"), "Select the Perfected strike you have", choices = Perfect_strike_options, selected = "NA"),
    numericInput(NS(id, "strike_cards"), label = "Number of Cards with Strike in the Name", value = 1, min = 0, max = 50, step = 1),
    selectInput(NS(id, "rampage"), "Select which version of rampage you have", choices = rampage_options, selected = "NA"),
    numericInput(NS(id, "rampage_n"), "How many times have you used the same rampage card", value = 0, min = 0, max = 50, step = 1),
    selectInput(NS(id, "isSearingBlow"), "Is the card Searing Blow", choices = searingBlow_options, selected = "FALSE"),
    numericInput(NS(id, "searingBlow_upgrades"), "How many times has searing blow been upgraded?", value = 0, min = 0, max = 50, step = 1),
    numericInput(NS(id, "strength"), label = "Strength Gained", value = 0, min = -5, max = 999, step = 1),
    selectInput(NS(id, "strength_x"), "Strength Multiplyer", choices = strength_mult, selected = 1),
    selectInput(NS(id, "weak"), "Weak Applied", choices = c(FALSE, TRUE), selected = "FALSE"),
    selectInput(NS(id, "vulnerable"), "Vulnerable Applied", choices = c(FALSE, TRUE), selected = "FALSE"),
    numericInput(NS(id, "x"), "X Hits", value = 1, min = 1, step = 1),
    verbatimTextOutput(NS(id, "damage"))
  )
}

# Ironclad damgage server

ironcladDamageServer <- function(id) {
  moduleServer(id,
               function(input, output, session) {
    output$damage <- renderText({
      dmg_dealt9(card = as.numeric(input$card),
                 perfected_strike = input$perfected_strike,
                 strike_count = input$strike_cards,
                 whichRampage = input$rampage,
                 rampages_used = input$rampage_n,
                 isSearing = input$isSearingBlow,
                 upgraded_n = input$searingBlow_upgrades,
                 strength = input$strength,
                 strength_multiplier = as.numeric(input$strength_x),
                 weak = input$weak, 
                 vulnerable = input$vulnerable, 
                 x = input$x)
      
    })

  })
}


# Ironclad card description module ----------------------------------------

# Ironclad card description UI

ironcladDescriptionUI <- function(id) {
  ns <- NS(id)
  tagList(
    selectInput(NS(id, "cardDescription"), "Select a card to get its description", choices = clad_info),
    verbatimTextOutput(NS(id, "description"))
  )
}

# Ironclad card description server

ironcladDescriptionServer <- function(id) {
  moduleServer(id, 
               function(input, output, session) {
                 output$description <- renderText({
                   print(input$cardDescription)
                 })
               })
}


# Image renderer Module ---------------------------------------------------

# Ironclad image UI

imageUI <- function(id) {
  ns <- NS(id)
  tagList(
    imageOutput(NS(id, "image"))
    
  )
}

# Ironclad image Server

imageServer <- function(id, filePath) {
  moduleServer(id,
               function(input, output, session) {
                 output$image <- renderImage({
                   list(
                     src = file.path(filePath),
                     contentType = "image/jpeg",
                     width = 600,
                     height = 900
                   )
                 }, deleteFile = FALSE)
               })
}


# HTML credit modules ------------------------------------------------------

# Ironclad HTML credit UI

ironcladcreditUI <- function(id) {
  ns <- NS(id)
  htmlOutput(NS(id, "credit"))
}

# Ironclad HTML credit Server

ironcladcreditServer <- function(id) {
  moduleServer(id,
               function(input, output, session) {
                 output$credit <- renderUI({
                   HTML(glue::glue("<p>
         <a href='https://www.deviantart.com/jasonwang7/art/Slay-the-Spire-Ironclad-864882630'>Original</a> by
         <a href='https://www.deviantart.com/jasonwang7'>jasonwang7</a> protected by Creative Commons 3.0 liscense
         </p>"))
                 })
                 
               })
}


# Silent HTML credit UI

silentcreditUI <- function(id) {
  ns <- NS(id)
  htmlOutput(NS(id, "credit"))
}

# Silent HTML credit Server

silentcreditServer <- function(id) {
  moduleServer(id,
               function(input, output, session) {
                 output$credit <- renderUI({
                   HTML(glue::glue("<p>
         <a href='https://www.deviantart.com/jasonwang7/art/Slay-the-Spire-Silent-864958909'>Original</a> by
         <a href='https://www.deviantart.com/jasonwang7'>jasonwang7</a> protected by Creative Commons 3.0 liscense
         </p>"))
                 })
                 
               })
}



# Defect HTML credit UI

defectcreditUI <- function(id) {
  ns <- NS(id)
  htmlOutput(NS(id, "credit"))
}

# Defect HTML credit Server

defectcreditServer <- function(id) {
  moduleServer(id,
               function(input, output, session) {
                 output$credit <- renderUI({
                   HTML(glue::glue("<p>
         <a href='https://www.deviantart.com/jasonwang7/art/Slay-the-Spire-Defect-865046560'>Original</a> by
         <a href='https://www.deviantart.com/jasonwang7'>jasonwang7</a> protected by Creative Commons 3.0 liscense
         </p>"))
                 })
                 
               })
}

# Watcher HTML credit UI

watchercreditUI <- function(id) {
  ns <- NS(id)
  htmlOutput(NS(id, "credit"))
}

# Watcher HTML credit Server

watchercreditServer <- function(id) {
  moduleServer(id,
               function(input, output, session) {
                 output$credit <- renderUI({
                   HTML(glue::glue("<p>
         <a href='https://www.deviantart.com/jasonwang7/art/Slay-the-Spire-Watcher-865135372'>Original</a> by
         <a href='https://www.deviantart.com/jasonwang7'>jasonwang7</a> protected by Creative Commons 3.0 liscense
         </p>"))
                 })
                 
               })
}



# APP ---------------------------------------------------------------------

# App UI

app_ui <- fluidPage(
  theme = theme1,
  tabsetPanel(
    tabPanel("Ironclad",
  titlePanel("Ironclad Damage Calculator"),
  fluidRow(
    column(8,
  useShinyjs(),
  div(
    id = "fullReset",
  ironcladDamageUI("damage1")
  ),
  actionButton("reset", "Reset All", class = "btn-warning")
), # Column 1
column(4,
       ironcladDescriptionUI("description1"),
       ironcladcreditUI("ironcladCredit"),
       imageUI("ironclad")
       ) # Column 2
) # fluidRow
), # tabPanel
tabPanel("Silent",
         titlePanel("Silent Damage Calculator"),
         fluidRow(
           column(4,
                  silentcreditUI("silentCredit"),
                  imageUI("silent")
                  )
         )
         ),
tabPanel("Defect",
         titlePanel("Defect Damage Calculator"),
         fluidRow(
           column(4,
                  defectcreditUI("defectCredit"),
                  imageUI("defect")
                  )
         )
         ),
tabPanel("Watcher",
         titlePanel("Watcher Damage Calculator"),
         fluidRow(
           column(4,
                  watchercreditUI("watcherCredit"),
                  imageUI("watcher")
                  )
         )
         )
) # tabsetPanel
) #fluidPage

# App server

app_server <- function(input, output, session) {
  ironcladDamageServer("damage1")
  observeEvent(input$reset, {
    reset("fullReset")
  })
  imageServer("ironclad", filePath = "images\\ironclad.jpg")
  imageServer("silent", filePath = "images\\silent.jpg")
  imageServer("defect", filePath = "images\\defect.jpg")
  imageServer("watcher", filePath = "images\\watcher.jpg")
  ironcladDescriptionServer("description1")
  ironcladcreditServer("ironcladCredit")
  silentcreditServer("silentCredit")
  defectcreditServer("defectCredit")
  watchercreditServer("watcherCredit")
}


# Run the application  ----------------------------------------------------

shinyApp(ui = app_ui, server = app_server)
