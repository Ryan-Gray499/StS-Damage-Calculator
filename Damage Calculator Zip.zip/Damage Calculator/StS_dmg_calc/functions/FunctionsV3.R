
# GPL 3.0 license ---------------------------------------------------------


#<This program is defines the functions needed for StS Damage Calculator>
#Copyright (C) <2024>  <Ryan Gray>

#This program is free software: you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation, either version 3 of the License, or
#(at your option) any later version.

#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.

#You should have received a copy of the GNU General Public License
#along with this program.  If not, see <https://www.gnu.org/licenses/>.




# Damage Functions --------------------------------------------------------

dmg_dealt9 <- function(card,
                       perfected_strike,
                       strike_count,
                       whichRampage,
                       rampages_used,
                       isSearing,
                       upgraded_n,
                       strength,
                       strength_multiplier,
                       x, 
                       vulnerable, 
                       weak) {
  perfect <- if (perfected_strike == "PerfectedStrike") {
    0 + 2 * strike_count
  } else if (perfected_strike == "PerfectedStrike_plus") {
    0 + 3 * strike_count
  } else {
    0 + 0
  }
  rampage <- if (whichRampage == "Rampage") {
    0 + 5 * rampages_used
  } else if (whichRampage == "Rampage_plus") {
    0 + 8 * rampages_used
  } else {
    0 + 0
  }
  searing <- if (isSearing == TRUE) {
    searing_blow(n = upgraded_n) - 12
  } else {
    0 + 0
  }
  dmg1 <- card + perfect + rampage + searing + strength * strength_multiplier
  dmg2 <- floor(ifelse(weak == TRUE, dmg1 * 0.75, dmg1 * 1))
  dmg3 <- floor(ifelse(vulnerable == TRUE, dmg2 * 1.5, dmg2 * 1))
  dmg4 <- dmg3 * x
  return(dmg4)
}

# searing blow

searing_blow <- function(n) {
  n * (n + 7) / 2 +12
}