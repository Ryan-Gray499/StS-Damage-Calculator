
# GPL 3.0 license ---------------------------------------------------------


#<This program provides the data required for StS Damage Calculator>
#Copyright (C) <2024>  <Ryan Gray>

#This program is free software: you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation, either version 3 of the License, or
#(at your option) any later version.

#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.

#You should have received a copy of the GNU General Public License
#along with this program.  If not, see <https://www.gnu.org/licenses/>.


# Dataframe of Cards ---------------------------------------------------------------

clad_cards <- c(
Anger = 6,
Anger_plus = 8,
Bash = 8,
Bash_plus = 10,
BloodforBlood = 18,
BloodforBlood_plus = 22,
Bludgeon = 32,
Bludgeon_plus = 42,
Carnage = 20,
Carnage_plus = 28,
Clash = 14,
Clash_plus = 18,
Cleave = 8,
Cleave_plus = 11,
Clothesline = 12,
Clothesline_plus = 14,
Dropkick = 5,
Dropkick_plus = 8,
Feed = 10,
Feed_plus = 12,
FiendFire = 7,
FiendFire_plus = 10,
Headbutt = 9,
Headbutt_plus = 12,
HeavyBlade = 14,
HeavyBlade_plus = 14,
Hemokinesis = 15,
Hemokinesis_plus = 20,
Immolate = 21,
Immolate_plus = 28,
IronWave = 5,
IronWave_plus = 7,
PerfectedStrike = 6,
PerfectedStrike_plus = 6,
PommelStrike = 9, 
PommelStrike_plus = 10,
Pummel = 2,
Pummel_plus = 2,
Rampage = 8,
Rampage_plus = 8,
Reaper = 4,
Reaper_plus = 5,
RecklessCharge = 7,
RecklessCharge_plus = 10,
SearingBlow = 12,
SeverSoul = 16,
SeverSoul_plus = 22,
Strike = 6,
Strike_plus = 9,
SwordBoomerang = 3,
SwordBoomerang_plus = 3,
Thunderclap = 4,
Thundreclap_plus = 7,
TwinStrike = 5,
TwinStrike_plus = 7,
Uppercut = 13,
Uppercut_plus = 13,
Whirlwind = 5,
Whirlwind_plus = 8,
WildStrike = 12,
WildStrike_plus = 17
)


# Strength Multiplier Options ---------------------------------------------

strength_mult <- c(1, 3, 5)


# Perfected strike options ------------------------------------------------

Perfect_strike_options <- c("PerfectedStrike", "PerfectedStrike_plus", "NA")


# Rampage Options ---------------------------------------------------------

rampage_options <- c("Rampage", "Rampage_plus", "NA")


# searing blow ------------------------------------------------------------

searingBlow_options <- c("TRUE", "FALSE")


# Card info ---------------------------------------------------------------

clad_info <- c(
  Anger = "Energy cost: 0 \n Damage: 6 \n Effects: add a copy to discard pile",
  Anger_plus = "Energy cost: 0 \n Damage: 8 \n Effects: add a copy to discard pile",
  Bash = "Energy cost: 2 \n Damage: 8 \n Effects: apply 2 vulnerable",
  Bash_plus = "Energy cost: 2 \n Damage: 10 \n Effects: apply 3 vulnerable",
  BloodforBlood = "Energy cost: 4 \n Damage: 18 \n Effects: cost 1 less energy each time HP is lost",
  BloodforBlood_plus = "Energy cost: 3 \n Damage: 22 \n Effects: cost 1 less energy each time HP is lost",
  Bludgeon = "Energy cost: 3 \n Damage: 32 \n Effects: no addiction effects",
  Bludgeon_plus = "Energy cost: 3 \n Damage: 42 \n Effects: no addiction effects",
  Carnage = "Energy cost: 2 \n Damage: 20 \n Effects: Ethereal",
  Carnage_plus = "Energy cost: 2 \n Damage: 28 \n Effects: Ethereal",
  Clash = "Energy cost: 0 \n Damage: 14 \n Effects: playable when every card in your hand is an attack",
  Clash_plus = "Energy cost: 0 \n Damage: 18 \n Effects: playable when every card in your hand is an attack",
  Cleave = "Energy cost: 1 \n Damage: 8 \n Effects: hits all enemies",
  Cleave_plus = "Energy cost: 1 \n Damage: 11 \n Effects: hits all enemies",
  Clothesline = "Energy cost: 2 \n Damage: 12 \n Effects: apply 2 weak",
  Clothesline_plus = "Energy cost: 2 \n Damage: 14 \n Effects: apply 3 weak",
  Dropkick = "Energy cost: 1 \n Damage: 5 \n Effects: if enemy is vulnerable, gain 1 energy and draw 1 card",
  Dropkick_plus = "Energy cost: 1 \n Damage: 8 \n Effects: if enemy is vulnerable, gain 1 energy and draw 1 card",
  Feed = "Energy cost: 1 \n Damage: 10 \n Effects: if fatal, gain 3 max HP",
  Feed_plus = "Energy cost: 1 \n Damage: 12 \n Effects: if fatal, gain 4 max HP",
  FiendFire = "Energy cost: 2 \n Damage: 7 \n Effects: exhaust all cards in hand, dealing 7 damage for each card \n exhausted",
  FiendFire_plus = "Energy cost: 2 \n Damage: 10 \n Effects: exhaust all cards in hand, dealing 10 damage for each card \n exhausted",
  Headbutt = "Energy cost: 1 \n Damage: 9 \n Effects: place 1 card from discard pile on top of your draw pile",
  Headbutt_plus = "Energy cost: 1 \n Damage: 12 \n Effects: place 1 card from discard pile on top of your draw pile",
  HeavyBlade = "Energy cost: 2 \n Damage: 14 \n Effects: strength affects this card 3 times",
  HeavyBlade_plus = "Energy cost: 2 \n Damage: 14 \n Effects: strength affects this card 5 times",
  Hemokinesis = "Energy cost: 1 \n Damage: 15 \n Effects: lose 2 HP",
  Hemokinesis_plus = "Energy cost: 1 \n Damage: 20 \n Effects: lose 2 HP",
  Immolate = "Energy cost: 2 \n Damage: 21 \n Effects: hits all enemies",
  Immolate_plus = "Energy cost: 2 \n Damage: 28 \n Effects: hits all enemies",
  IronWave = "Energy cost: 1 \n Damage: 5 \n Effects: gain 5 block",
  IronWave_plus = "Energy cost: 1 \n Damage: 7 \n Effects: gain 7 block",
  PerfectedStrike = "Energy cost: 2 \n Damage: 6 \n Effects: deal an additional 2 damage for every card containing strike",
  PerfectedStrike_plus = "Energy cost: 2 \n Damage: 6 \n Effects: deal an additional 3 damage for every card containing strike",
  PommelStrike = "Energy cost: 1 \n Damage: 9 \n Effects: draw 1 card", 
  PommelStrike_plus = "Energy cost: 1 \n Damage: 10 \n Effects: draw 2 card",
  Pummel = "Energy cost: 1 \n Damage: 2 \n Effects: hits 4 times. Exhaust",
  Pummel_plus = "Energy cost: 1 \n Damage: 2 \n Effects: hits 5 times. Exhaust",
  Rampage = "Energy cost: 1 \n Damage: 8 \n Effects: increase this card's damage by 5 every time it's used",
  Rampage_plus = "Energy cost: 1 \n Damage: 8 \n Effects: increase this card's damage by 8 every time it is used",
  Reaper = "Energy cost: 2 \n Damage: 4 \n Effects: hits all enemies and heal HP equal to unblocked damage. \n Exhaust",
  Reaper_plus = "Energy cost: 2 \n Damage: 5 \n Effects: hits all enemies and heal HP equal to unblocked damage. \n Exhaust",
  RecklessCharge = "Energy cost: 0 \n Damage: 7 \n Effects: shuffle a dazed into your draw pile",
  RecklessCharge_plus = "Energy cost: 0 \n Damage: 10 \n Effects: shuffle a dazed into your draw pile",
  SearingBlow = "Energy cost: 2 \n Damage: 12 \n Effects: can be upgraded infinitely",
  SeverSoul = "Energy cost: 2 \n Damage: 16 \n Effects: exhause all non-attack cards in your hand",
  SeverSoul_plus = "Energy cost: 2 \n Damage: 22 \n Effects: exhause all non-attack cards in your hand",
  Strike = "Energy cost: 1 \n Damage: 6 \n Effects: no addiction effects",
  Strike_plus = "Energy cost: 1 \n Damage: 9 \n Effects: no addiction effects",
  SwordBoomerang = "Energy cost: 1 \n Damage: 3 \n Effects: hits 3 times",
  SwordBoomerang_plus = "Energy cost: 1 \n Damage: 3 \n Effects: hits 4 times",
  Thunderclap = "Energy cost: 1 \n Damage: 4 \n Effects: apply 1 vulnerable and hits all enemies",
  Thundreclap_plus = "Energy cost: 1 \n Damage: 7 \n Effects: apply 1 vulnerable and hits all enemies",
  TwinStrike = "Energy cost: 1 \n Damage: 5 \n Effects: hits 2 times",
  TwinStrike_plus = "Energy cost: 1 \n Damage: 7 \n Effects: hits 2 times",
  Uppercut = "Energy cost: 2 \n Damage: 13 \n Effects: apply 1 weak and 1 vulnerable",
  Uppercut_plus = "Energy cost: 2 \n Damage: 13 \n Effects: apply 2 weak and 2 vulnerable",
  Whirlwind = "Energy cost: X \n Damage: 5 \n Effects: hits all enemies X times",
  Whirlwind_plus = "Energy cost: X \n Damage: 8 \n Effects: hits all enemies X time",
  WildStrike = "Energy cost: 1 \n Damage: 12 \n Effects: shuffle a wound into your draw pile",
  WildStrike_plus = "Energy cost: 1 \n Damage: 17 \n Effects: shuffle a wound into your draw pile"
)

